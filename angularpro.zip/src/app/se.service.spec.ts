import { TestBed } from '@angular/core/testing';

import { SeService } from './se.service';

describe('SeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SeService = TestBed.get(SeService);
    expect(service).toBeTruthy();
  });
});
