import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
 user:any;
 collapse:boolean=true;
  constructor() { 
    this.user={name:'Amrutha',
  job:'Ajce',
  address:'1234 Kottayam,city,state,1234',
  phone:
    ['123-123-123',
    '1234-1234-1234']
}; 
  }
  toggle(){
    this.collapse=!this.collapse;
  }

  ngOnInit() {
  }

}
