import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Student } from '../student';
import { SeService } from '../se.service';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
student=new Student();
error:string;
success='';
  constructor(private seService: SeService) { 


  }

  ngOnInit() {
  }
  registration(f:NgForm)
  {
    this.seService.store(this.student).subscribe(
      data=>{this.success="Successfully inserted";
        f.reset();


  },
  (err)=>{this.error="error occured";})

}
}
